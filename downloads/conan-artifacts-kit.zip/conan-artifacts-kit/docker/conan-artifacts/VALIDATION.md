# 首批实际验收（2026-09-09）

## 已通过的本地结果

- 构建镜像：`lsqy-conan-artifacts:ubuntu22.04-gcc11-conan2.15.0`。
- 镜像 ID：`sha256:186c62522e848eda009648568aaf7277ad7e809810f7afaad75cb8cffef0c51f`。
- 已验收批次：`20260909T021123Z-41b2b1e8`。
- Docker daemon arm64 / 容器 aarch64，Ubuntu 22.04，GCC 11.4.0，CMake 3.22.1，Conan 2.15.0，glibc 2.35。
- 8 个直接依赖 + zlib 1.3.2 / libiconv 1.17，共 10 个配方、18 个制品：8 个编译型库各有 Release/Debug，2 个 header-only 包各一份。
- `conan-cache.tgz` 为 42,863,667 字节；每个制品都实际包含许可文件，额外收集副本不等于许可完整审计。

生产端两种配置均从源码构建（`--build=*`），分别通过 CTest 和安装后运行。消费端在 Docker `--network none`、全新缓存中恢复后，同样分别编译、CTest 和运行安装后的程序。每次消费有 5 项 GTest，覆盖所有八个直接依赖，不使用 Release 下被移除的 assert。

六组闭环检查全部通过：空缓存拒绝、恢复完整性、Release 消费、Debug 消费、完整身份集合一致、未准备 SDK 基线拒绝。`ldd` 没有 not found；程序仍动态依赖 glibc/libstdc++/libm/libgcc，不是完全静态部署包。

同一 bundle 在第二个全新断网容器中再次完整通过，确认验证没有改变归档输入。构建镜像也已导出为 `build/conan-artifacts/builder-186c62522e84.tar`（178,531,328 字节），生成并复查了同目录 `.sha256` 校验文件；只验证本机导出完整性，没有在第二台机器导入运行。

`tools/test-conan-artifacts.py` 的 8 项回归在 Docker 内通过：包含 PREV 合并、时间戳独立性、归档修改/增删/符号链接、路径拒绝，以及预检查失败不会继续报告旧 PASS。

## 真实记录和复查

完整 producer 日志：`build/conan-artifacts/runs/<run-id>/transcript.txt`；每次 verifier 在独立的 `build/conan-artifacts/verify-*/` 留下日志与 JSON。最近结果另外写入批次的 verification.json。

小型可提交证据在 [recorded-summary.json](recorded-summary.json)，由 `node tools/snapshot-conan-artifacts.mjs` 对当前通过报告、制品哈希、消费源码、验证脚本和真实日志校验后生成。它是一次实际运行的快照，不代表其他机器或后续源码自动通过。库、缓存和镜像本体不进入 Git/博客。

本轮排除了两处实际兼容问题：

1. spdlog 1.15.1 的冻结配方要求 fmt 11.1.3，将直接依赖按此对齐，没有强行 override 成不匹配版本。
2. Conan 2.15.0 的 `cache check-integrity` 只接受 pattern，不支持新版 `--list`。目前只检查本任务独立缓存的 `*#*:*#*`，cache save 仍按完整 PackageList 选择内容。

另关闭 CMakeUserPresets 的源码写入，verifier 使用 consumer 副本，避免归档因验证自身而改变。所有失败生产批次仍保留状态与日志，未伪装成通过批次，也没有删除用户文件。

## 尚未验证

没有跨机恢复、原生 AMD64、Windows/macOS 原生库、高通交叉编译/上板、远端制品服务器、漏洞扫描、许可证完整审计，也没有将现有机器人应用从 APT 改到 Conan。

本轮网页仅新增原 Conan 文章第 15 节，没有主题或布局改动。浏览器工具返回 No browser is available，发现列表为空，故桌面/手机视觉截图尚未执行；未用其他驱动绕过此限制。

源代码与文档未提交或推送。后续扩展前先看 [TODO.md](TODO.md)。
