from conan import ConanFile
from conan.tools.cmake import CMakeDeps, CMakeToolchain, cmake_layout


class ArtifactConsumer(ConanFile):
    """A real consumer of the pinned, reusable binary artifact collection."""

    settings = "os", "arch", "compiler", "build_type"
    requires = (
        "eigen/3.4.0",
        "fmt/11.1.3",
        "spdlog/1.15.1",
        "nlohmann_json/3.11.3",
        "yaml-cpp/0.8.0",
        "tinyxml2/10.0.0",
        "gtest/1.15.0",
        "libxml2/2.13.8",
    )
    default_options = {
        "*:shared": False,
        "libxml2/*:include_utils": False,
    }

    def layout(self):
        cmake_layout(self)

    def generate(self):
        CMakeDeps(self).generate()
        toolchain = CMakeToolchain(self)
        # The bundle must not contain presets pointing into a producer's cache.
        toolchain.user_presets_path = False
        toolchain.generate()
