#include <Eigen/Dense>
#include <fmt/format.h>
#include <gtest/gtest.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <nlohmann/json.hpp>
#include <spdlog/logger.h>
#include <spdlog/sinks/ostream_sink.h>
#include <tinyxml2.h>
#include <yaml-cpp/yaml.h>

#include <memory>
#include <sstream>
#include <string>
#include <vector>

namespace {

using Json = nlohmann::json;

Json configuration_from_yaml(const YAML::Node& node) {
    return {
        {"robot", node["robot"].as<std::string>()},
        {"enabled", node["enabled"].as<bool>()},
        {"gains", node["gains"].as<std::vector<double>>()},
    };
}

TEST(ArtifactSmoke, EigenSolvesLinearSystem) {
    Eigen::Matrix3d matrix;
    matrix << 4.0, 1.0, 0.0,
              1.0, 3.0, 1.0,
              0.0, 1.0, 2.0;
    const Eigen::Vector3d rhs(2.0, -2.0, 4.0);
    const Eigen::Vector3d solution = matrix.ldlt().solve(rhs);
    const Eigen::Vector3d expected(1.0, -2.0, 3.0);

    EXPECT_LT((matrix * solution - rhs).norm(), 1e-12);
    EXPECT_LT((solution - expected).norm(), 1e-12);
}

TEST(ArtifactSmoke, FmtFormatsAndSpdlogWritesMessage) {
    const std::string message = fmt::format("{}: samples={}, residual={:.3f}",
                                            "artifact-smoke", 8, 0.125);
    EXPECT_EQ(message, "artifact-smoke: samples=8, residual=0.125");

    std::ostringstream output;
    auto sink = std::make_shared<spdlog::sinks::ostream_sink_mt>(output);
    spdlog::logger logger("artifact-smoke", sink);
    logger.set_pattern("%v");
    logger.info("{}", message);
    logger.flush();

    EXPECT_EQ(output.str(), message + "\n");
}

TEST(ArtifactSmoke, YamlAndJsonRoundTripPreservesConfiguration) {
    const auto yaml = YAML::Load(
        "robot: arm64-lab\n"
        "enabled: true\n"
        "gains: [1.5, 2.0, 0.25]\n");
    const Json configuration = configuration_from_yaml(yaml);
    const Json decoded = Json::parse(configuration.dump());
    EXPECT_EQ(decoded.at("robot"), "arm64-lab");
    EXPECT_EQ(decoded.at("enabled"), true);
    EXPECT_EQ(decoded.at("gains"), Json::array({1.5, 2.0, 0.25}));

    YAML::Node rebuilt;
    rebuilt["robot"] = decoded.at("robot").get<std::string>();
    rebuilt["enabled"] = decoded.at("enabled").get<bool>();
    rebuilt["gains"] = decoded.at("gains").get<std::vector<double>>();
    YAML::Emitter emitter;
    emitter << rebuilt;
    ASSERT_TRUE(emitter.good());

    EXPECT_EQ(configuration_from_yaml(YAML::Load(emitter.c_str())), configuration);
}

TEST(ArtifactSmoke, TinyXml2ParsesAndSerializesDocument) {
    tinyxml2::XMLDocument document;
    ASSERT_EQ(document.Parse(
        "<robot name=\"artifact-smoke\"><joint limit=\"1.25\">elbow</joint></robot>"),
        tinyxml2::XML_SUCCESS);
    const auto* robot = document.FirstChildElement("robot");
    ASSERT_NE(robot, nullptr);
    EXPECT_STREQ(robot->Attribute("name"), "artifact-smoke");
    const auto* joint = robot->FirstChildElement("joint");
    ASSERT_NE(joint, nullptr);
    double limit = 0.0;
    ASSERT_EQ(joint->QueryDoubleAttribute("limit", &limit), tinyxml2::XML_SUCCESS);
    EXPECT_DOUBLE_EQ(limit, 1.25);
    EXPECT_STREQ(joint->GetText(), "elbow");

    tinyxml2::XMLPrinter printer;
    document.Print(&printer);
    tinyxml2::XMLDocument restored;
    ASSERT_EQ(restored.Parse(printer.CStr()), tinyxml2::XML_SUCCESS);
    ASSERT_NE(restored.FirstChildElement("robot"), nullptr);
    EXPECT_STREQ(restored.FirstChildElement("robot")->Attribute("name"),
                 "artifact-smoke");
}

struct XmlStringDeleter {
    void operator()(xmlChar* value) const { xmlFree(value); }
};

TEST(ArtifactSmoke, LibXml2ParsesDocumentWithOwnedResources) {
    const std::string source =
        "<robot name=\"artifact-smoke\"><joint>shoulder</joint></robot>";
    std::unique_ptr<xmlDoc, decltype(&xmlFreeDoc)> document(
        xmlReadMemory(source.data(), static_cast<int>(source.size()),
                      "artifact-smoke.xml", nullptr, XML_PARSE_NONET),
        &xmlFreeDoc);
    ASSERT_NE(document, nullptr);
    const xmlNode* robot = xmlDocGetRootElement(document.get());
    ASSERT_NE(robot, nullptr);
    EXPECT_STREQ(reinterpret_cast<const char*>(robot->name), "robot");

    std::unique_ptr<xmlChar, XmlStringDeleter> name(
        xmlGetProp(robot, reinterpret_cast<const xmlChar*>("name")));
    ASSERT_NE(name, nullptr);
    EXPECT_STREQ(reinterpret_cast<const char*>(name.get()), "artifact-smoke");

    const xmlNode* joint = robot->children;
    while (joint && joint->type != XML_ELEMENT_NODE) {
        joint = joint->next;
    }
    ASSERT_NE(joint, nullptr);
    EXPECT_STREQ(reinterpret_cast<const char*>(joint->name), "joint");
    std::unique_ptr<xmlChar, XmlStringDeleter> content(xmlNodeGetContent(joint));
    ASSERT_NE(content, nullptr);
    EXPECT_STREQ(reinterpret_cast<const char*>(content.get()), "shoulder");
}

}  // namespace

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    xmlInitParser();
    const int result = RUN_ALL_TESTS();
    xmlCleanupParser();
    return result;
}
