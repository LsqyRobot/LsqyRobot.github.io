# 常用 C++ 制品架：构建一次，按配置复用

这是独立的 Docker + Conan 2.15.0 本地制品工作流，不是给旧机器人镜像原地安装依赖，也不是已经部署的多人制品服务器。镜像负责固定编译环境，Conan 保存库和兼容性身份，lockfile 固定依赖配方，PackageList 固定完整二进制引用。

## 第一批范围

| 直接依赖 | 版本 | 用途与当前关系 |
| --- | --- | --- |
| libxml2 | 2.13.8 | 当前辨识/标定项目使用其 API；这里预备 Conan 制品，尚未将原 APT 依赖替换 |
| Eigen | 3.4.0 | 线性代数，已有笔记示例使用 |
| TinyXML2 | 10.0.0 | 轻量 XML；与 libxml2 是两套 API，不互相替代 |
| GoogleTest | 1.15.0 | 后续 C++ 单元测试 |
| fmt | 11.1.3 | 新增通用储备：类型安全格式化；与 spdlog 的配方依赖一致 |
| spdlog | 1.15.1 | 新增通用储备：日志 |
| nlohmann_json | 3.11.3 | 新增通用储备：JSON 配置/结果 |
| yaml-cpp | 0.8.0 | 新增通用储备：机器人 YAML 参数 |

版本是本次验证基线，不是“最新版本”或经过漏洞扫描的推荐。libxml2 的 zlib/libiconv 等传递依赖必须随实际图一起保存，不能只压缩上表八个目录。

首批配置：Ubuntu 22.04、GCC 11、libstdc++11 ABI、C++17、静态库、Release/Debug。本机实测架构以生成报告为准；AMD64 分支没有因为存在代码就被视为已验收。Eigen/JSON 等 header-only 包也保留配方与消费测试。

## 日常使用

在站点仓库根目录：

```bash
./bin/site.sh artifacts-build
./bin/site.sh artifacts-create
./bin/site.sh artifacts-verify
./bin/site.sh artifacts-status
```

直接入口等价于 `bash docker/conan-artifacts/run.sh build/create/verify/status`。构建镜像和第一次获取上游源码需要网络；verify 明确 `--network none`。

上述是建立/更新制品架的流程，不是每次编译自己工程都运行一遍。已有验证通过的 bundle 后，新工程只需恢复并消费；只有增加库、升级版本或改变平台配置时才重新 create。

如果还没有当前架构的审核锁，create 会拒绝自动跟随远端变化。首次显式使用 `artifacts-create --bootstrap`；检查成功批次的 `bundle/conan.lock` 后，将其作为对应架构的 `docker/conan-artifacts/locks/armv8.lock` 或 `x86_64.lock` 固化，再进行日常构建。锁不包含系统包、编译器或完整二进制身份。

每次 create 生成新批次，不覆盖旧包：

```text
build/conan-artifacts/
  last-built                 # 最近构建成功，不等于验收通过
  last-verified              # 最近通过离线消费的批次
  runs/<run-id>/
    state.json
    transcript.txt           # 真实命令、输出、退出码
    verification.json
    bundle/
      conan-cache.tgz        # Conan 官方 cache save 格式
      conan.lock
      profiles/             # build / Release / Debug
      consumer/             # CMake 可运行消费示例
      packages.json         # 完整 RREV / package ID / PREV
      graph-*.json
      licenses/             # 包内实际携带的许可文本副本
      manifest.json         # 镜像、环境、输入和制品 SHA-256
```

原始缓存/编译工作区保留在该批次下方便排错，但迁移消费只需要 `bundle` 和匹配的工具镜像。不将本地 `.a`、ELF、缓存、镜像归档放进 Hexo public 或 Git。

## 离线验收为什么必要

verify 创建全新缓存和独立消费源码副本，依次验证：

1. 空缓存安装失败，证明没有悄悄借用已有包。
2. 校验 bundle 文件哈希，`conan cache restore` 恢复并检查缓存完整性。
3. `--no-remote --build=never` 分别安装 Release/Debug，不允许临时编译依赖凑齐环境。
4. 重新生成 CMake 配置，编译消费程序，执行 CTest，再运行安装后的程序。
5. 比较恢复前后的 RREV/package ID/PREV 集合，不比较 Conan 会更新的时间戳。
6. 故意换成尚未准备的 SDK 基线，要求拒绝使用现有二进制。

五项 GTest 覆盖真实的 Eigen 求解、fmt/spdlog 输出、YAML/JSON 往返、TinyXML2 与 libxml2 解析，Release 下断言仍有效。这不是八个项目的完整上游测试或产品级认证。

## 接到自己的工程

从 bundle/consumer 的 conanfile.py、CMakeLists.txt 开始，保留实际需要的依赖。在**相同工具镜像的独立可写缓存**中：

```bash
conan cache restore /bundle/conan-cache.tgz
conan install /project -of /work/my-build \
  -pr:b /bundle/profiles/build -pr:h /bundle/profiles/Release \
  --lockfile=/bundle/conan.lock --build=never --no-remote
```

`/bundle`、`/project`、`/work` 是自己的容器挂载点，不是宿主上预先存在的目录。CMake 按生成的 conan_toolchain.cmake 配置，链接 imported targets，不硬编码缓存绝对路径。新增依赖或改变条件依赖后需重新审查锁；不能假设这一份锁覆盖任意项目。

profile 使用 `tools.info.package_id:confs` 将 `user.lsqy:baseline` 纳入制品身份，防止裸 `Linux/armv8` 配置误用这个 Ubuntu 基线。**这个字段不是自动 SDK 检测器**：真实 SDK、sysroot、libc、ABI 契约变化时需要新基线和新构建。验证器还要求与生产时相同的工具镜像 ID。

静态打包的是这些第三方库，不是全静态操作系统。安装后的测试程序仍依赖 glibc/libstdc++ 等系统库，报告保留 `ldd` 输出。Docker 能统一构建用户态环境，不能替代目标板内核、驱动、NPU SDK 与实机验证。

## 迁移与备份

```bash
./bin/site.sh artifacts-image-save
# 在同架构新机器安装 Docker 后，导入本次保存的镜像：
docker load --input build/conan-artifacts/builder-186c62522e84.tar
```

同时保存本目录源代码、已验证批次 bundle、verification.json 和日志；按原目录结构放回新的仓库根目录再执行 `artifacts-verify <run-id>`。只复制 Conan 缓存不能代替工具镜像。不同物理架构需要各自产出与验收；不要把 QEMU 成功称为原生验收。

源码 ZIP 解压后，本目录已经处于 `docker/conan-artifacts/` 的相对位置。把 bundle 放到 `build/conan-artifacts/runs/20260909T021123Z-41b2b1e8/bundle/`，即可从解压根目录执行 `bash docker/conan-artifacts/run.sh verify 20260909T021123Z-41b2b1e8`。未搬迁实测的步骤仍不作为通过记录。

cache save 包含 recipe/source 元数据和打包文件，但不包含全局 profile、Conan 客户端、编译器、操作系统。这里只承诺经过验证的离线**消费**，不承诺任意包在完全断网环境重新源码构建。

## 安全、升级与后续

- 独立非 root 容器，源码只读，capabilities 全删；没有端口、宿主 Docker socket、远端上传或用户凭据挂载。
- 每次任务独立缓存，避免并发共享 Conan cache。不同验证记录独立保留。
- 固定版本/哈希是完整性和可追溯基础，不等于代码可信、许可证合规或无漏洞。先进行审计再向他人/远端发布。
- 升级从新批次开始：改版本/配置 → 更新并审查锁 → 构建 → 离线消费 → 保留旧批次再切换。不要只覆盖“latest”文件。
- 当前没有安装 Artifactory/Nexus。需要多人共享时再选择仓库、认证、TLS 和备份策略。
- Pinocchio、Boost/OpenCV、ONNX Runtime、ROS2、OCS2、高通 SDK 属于后续单独的功能/平台组合，不由本批通用库替代。见 [TODO](TODO.md)。

依据：[Conan 2.15 手册的缓存保存/恢复章节](https://docs.conan.io/2.15/conan.pdf)、[lockfiles](https://docs.conan.io/2.15/tutorial/versioning/lockfiles.html)、[CMakeDeps](https://docs.conan.io/2.15/reference/tools/cmake/cmakedeps.html)。固定客户端不支持新版 `cache save --no-source`，本脚本没有使用它。
