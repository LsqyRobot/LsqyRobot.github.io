# 制品架状态与待办

## 实现，不等于实测

- 独立 Dockerfile、八个直接依赖和真实 CMake/GTest 消费程序。
- Release/Debug 生产、完整图/PackageList/锁与哈希归档。
- 空缓存反例、断网恢复、编译/安装后运行与未准备基线拒绝。
- 统一入口 `./bin/site.sh artifacts-*`；输出仅在 build/conan-artifacts。

实际已验收批次以本地 `verification.json` 的 status=passed 为准。本轮最终结果记录在 VALIDATION.md；没有记录的架构或功能不能按完成处理。

## P1：目标平台与机器人依赖

- 高通：需要板型、BSP/SDK 版本、sysroot、libc/编译器 ABI、部署方式。为目标 SDK 新建 profile 与 baseline，不沿用 Ubuntu 二进制；交叉构建后检查 ELF 和动态依赖，最后上板运行。入口 manage.py/profile 与 consumer/。
- 原生 AMD64：需要对应机器或可信原生 CI runner，构建两个配置，复跑全部离线检查并记录镜像/平台，不能用 ARM64 上的 QEMU 代替。
- Pinocchio：现有示例 EXACT 3.8.0；需要明确 Boost/Eigen/URDF 依赖与数值回归后单独加入，不用“包能编译”代替浮动基动力学正确性。
- OpenCV/Boost：明确组件、GUI/视频/并行/共享库需求再扩展，避免无边界构建整个生态。
- ONNX Runtime/ROS2/OCS2：维持现有各环境版本契约，需要单独迁移计划与实际消费验证。

## P1：发布和长期维护

- 制品远端：用户选定并授权服务器/凭据后，验证上传、干净缓存下载、权限拒绝和备份恢复；本轮不部署或上传。
- 许可证/SBOM/漏洞：当前仅收集包内已有许可，不是法律或供应链完整审查。引入扫描、上游补丁追踪、过期版本替换后再发布给别人。
- 系统环境冻结：APT snapshot、Python 带哈希锁、镜像保留与灾难恢复。当前 Conan/base digest 固定，其余版本记录但未完全冻结。

## P2：更完整的部署闭环

- shared 与独立最小运行镜像：需对每个库明确运行时依赖、SONAME、RPATH 和 license；当前静态第三方库仍依赖系统动态库。
- 第二台同架构机器离线恢复：搬迁镜像+bundle+源码后复测，当前单机新容器验证不等于跨机验证。
- 接入原辨识/标定工程：这次没有替换原 APT libxml2；后续应同时跑两套工程的原有数值与 API 回归。
