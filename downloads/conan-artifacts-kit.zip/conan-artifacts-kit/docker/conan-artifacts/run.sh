#!/usr/bin/env bash
set -euo pipefail
artifact_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
artifact_image="lsqy-conan-artifacts:ubuntu22.04-gcc11-conan2.15.0"
artifact_store="$artifact_root/build/conan-artifacts"
artifact_action="${1:-status}"
if [[ $# -gt 0 ]]; then shift; fi
case "$artifact_action" in
  build)
    [[ $# == 0 ]] || exit 2
    docker build -t "$artifact_image" -f "$artifact_root/docker/conan-artifacts/Dockerfile" "$artifact_root/docker/conan-artifacts"
    ;;
  create|verify|status)
    artifact_uid="$(id -u)"
    [[ "$artifact_uid" != 0 ]] || { echo '请以普通用户运行，不要 sudo。' >&2; exit 2; }
    mkdir -p "$artifact_store"
    artifact_image_id="$(docker image inspect --format '{{.Id}}' "$artifact_image")"
    artifact_daemon_arch="$(docker info --format '{{.Architecture}}')"
    artifact_target_arch="$(docker image inspect --format '{{.Architecture}}' "$artifact_image_id")"
    case "$artifact_daemon_arch" in aarch64) artifact_daemon_arch=arm64;; x86_64) artifact_daemon_arch=amd64;; esac
    [[ "$artifact_daemon_arch" == "$artifact_target_arch" ]] || { echo '此入口只验证 Docker daemon 的原生架构，不自动使用模拟器。' >&2; exit 2; }
    artifact_network=none
    [[ "$artifact_action" != create ]] || artifact_network=bridge
    docker run --rm --init --read-only --cap-drop ALL \
      --security-opt no-new-privileges --user "$artifact_uid:$(id -g)" \
      --memory 4g --cpus 4 --pids-limit 256 --network "$artifact_network" \
      --tmpfs /tmp:rw,exec,nosuid,nodev,mode=1777,size=128m \
      --env "ARTIFACT_IMAGE_ID=$artifact_image_id" \
      --env "ARTIFACT_DAEMON_ARCH=$artifact_daemon_arch" \
      --mount "type=bind,source=$artifact_root/docker/conan-artifacts,target=/kit,readonly" \
      --mount "type=bind,source=$artifact_store,target=/store" \
      "$artifact_image_id" python3 -B /kit/manage.py "$artifact_action" "$@"
    ;;
  image-save)
    [[ $# == 0 ]] || exit 2
    mkdir -p "$artifact_store"
    artifact_short_id="$(docker image inspect --format '{{.Id}}' "$artifact_image")"
    artifact_short_id="${artifact_short_id#sha256:}"
    artifact_archive="$artifact_store/builder-${artifact_short_id:0:12}.tar"
    if [[ -e "$artifact_archive" ]]; then
      [[ -f "$artifact_archive.sha256" ]] || { echo '已有归档缺少校验和，请人工检查；未覆盖。' >&2; exit 2; }
      (cd "$artifact_store" && shasum -a 256 --check "${artifact_archive##*/}.sha256")
      exit
    fi
    artifact_tmp="$(mktemp "$artifact_store/builder-export.XXXXXX")"
    docker image save --output "$artifact_tmp" "$artifact_image"
    mv "$artifact_tmp" "$artifact_archive"
    # Generated checksum sidecar uses a relative filename for migration.
    (cd "$artifact_store" && shasum -a 256 "${artifact_archive##*/}") > "$artifact_archive.sha256"
    echo "已保存：$artifact_archive"
    ;;
  *)
    echo '用法：bash docker/conan-artifacts/run.sh {build|create [--bootstrap]|verify [run-id]|status|image-save}' >&2
    exit 2
    ;;
esac
