#!/usr/bin/env python3
"""Build a scoped library shelf, then restore it in a fresh offline consumer.

Only invoked inside the declared Docker builder. Generated files stay in /store;
no host cache, global toolchain, registry upload or existing service is involved.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import tempfile
import uuid

KIT = Path('/kit')
STORE = Path('/store')
BASELINE = 'ubuntu22.04-gcc11-glibc2.35-cpp17-static-v1'


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def tree_hashes(root):
    result = {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise RuntimeError(f'Symlinks are not valid kit inputs: {path}')
        if path.is_file():
            result[str(path.relative_to(root))] = digest(path)
    return result


def identity_set(package_list):
    identities = set()
    for ref, recipe in package_list.get('Local Cache', {}).items():
        for rrev, revision in recipe.get('revisions', {}).items():
            identities.add(f'{ref}#{rrev}')
            for pid, package in revision.get('packages', {}).items():
                for prev in package.get('revisions', {}):
                    identities.add(f'{ref}#{rrev}:{pid}#{prev}')
    return identities


def merge_lists(lists):
    result = {'Local Cache': {}}
    for package_list in lists:
        for ref, recipe in package_list['Local Cache'].items():
            target = result['Local Cache'].setdefault(ref, {'revisions': {}})
            for rrev, revision in recipe['revisions'].items():
                dest = target['revisions'].setdefault(rrev, {'packages': {}})
                for key, value in revision.items():
                    if key != 'packages':
                        dest[key] = value
                for pid, package in revision.get('packages', {}).items():
                    item = dest['packages'].setdefault(pid, {'revisions': {}})
                    item['revisions'].update(package.get('revisions', {}))
                    for key, value in package.items():
                        if key != 'revisions':
                            item[key] = value
    return result


class Session:
    def __init__(self, root):
        self.root = root
        self.commands = []
        self.log = (root / 'transcript.txt').open('w', buffering=1)
        self.env = os.environ.copy()
        self.env['CONAN_HOME'] = str(root / 'cache')
        # Avoid inherited user credentials or arbitrary compiler/profile overrides.
        for key in list(self.env):
            if key.startswith(('CONAN_LOGIN_', 'CONAN_PASSWORD')):
                self.env.pop(key)
        self.env['CONAN_NON_INTERACTIVE'] = '1'

    def run(self, *args, cwd=None, failure=False):
        argv = [str(arg) for arg in args]
        print('$ ' + ' '.join(argv), flush=True)
        self.log.write('\n$ ' + ' '.join(argv) + '\n')
        process = subprocess.run(argv, cwd=cwd or self.root, env=self.env,
                                 stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 text=True, timeout=1800)
        self.log.write(process.stdout + '\n' + process.stderr)
        self.log.write(f'\n[exit_code={process.returncode}]\n')
        self.commands.append({'argv': argv, 'exit_code': process.returncode,
                              'expected_failure': failure})
        if (process.returncode == 0) == failure:
            print((process.stdout + process.stderr)[-16000:], flush=True)
            raise RuntimeError(f'Unexpected exit {process.returncode}: {argv}')
        return process.stdout + process.stderr

    def environment(self):
        version = self.run('conan', '--version').strip()
        if version != 'Conan version 2.15.0':
            raise RuntimeError('Use the declared Conan 2.15.0 builder')
        compiler = self.run('g++', '-dumpfullversion').strip()
        if not compiler.startswith('11.'):
            raise RuntimeError('This baseline requires GCC 11')
        distro = Path('/etc/os-release').read_text()
        if 'ID=ubuntu' not in distro or 'VERSION_ID="22.04"' not in distro:
            raise RuntimeError('This baseline requires Ubuntu 22.04')
        return {'conan': version, 'compiler': compiler, 'architecture': platform.machine(),
                'docker_daemon_architecture': os.environ['ARTIFACT_DAEMON_ARCH'],
                'compiler_target': self.run('g++', '-dumpmachine').strip(),
                'cmake': self.run('cmake', '--version').splitlines()[0],
                'glibc': self.run('ldd', '--version').splitlines()[0],
                'os_release': distro,
                'python_dependencies': self.run('pip', 'freeze').splitlines(),
                'system_packages': self.run('dpkg-query', '-W', '-f=${Package}=${Version}\n').splitlines()}


def profile(arch, build_type):
    return f'''# Validated baseline, NOT a target-board SDK profile.
[settings]
os=Linux
arch={arch}
compiler=gcc
compiler.version=11
compiler.libcxx=libstdc++11
compiler.cppstd=17
build_type={build_type}
[conf]
tools.build:jobs=4
tools.gnu:pkg_config=/usr/bin/pkg-config
tools.info.package_id:confs=["user.lsqy:baseline"]
user.lsqy:baseline={BASELINE}
'''


def check_graph(graph):
    nodes = list(graph['graph']['nodes'].values())
    bad = [node for node in nodes if node.get('binary') in ('Missing', 'Invalid')]
    if bad:
        raise RuntimeError('Cannot archive an incomplete dependency graph')
    return nodes


def compile_consumer(session, consumer, output, build_type):
    build = output / 'build' / build_type
    session.run('cmake', '-S', consumer, '-B', build,
                f'-DCMAKE_TOOLCHAIN_FILE={build}/generators/conan_toolchain.cmake',
                f'-DCMAKE_BUILD_TYPE={build_type}', '-DBUILD_TESTING=ON')
    session.run('cmake', '--build', build, '--parallel', '4')
    tests = session.run('ctest', '--test-dir', build, '--output-on-failure', '--no-tests=error')
    prefix = output / 'installed'
    session.run('cmake', '--install', build, '--prefix', prefix)
    result = session.run(prefix / 'bin' / 'artifact-smoke')
    return {'ctest_output': tests, 'installed_output': result,
            'executable_sha256': digest(prefix / 'bin' / 'artifact-smoke'),
            'runtime_libraries': session.run('ldd', prefix / 'bin' / 'artifact-smoke')}


def create(bootstrap):
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ-') + uuid.uuid4().hex[:8]
    root = STORE / 'runs' / run_id
    root.mkdir(parents=True)
    bundle = root / 'bundle'
    bundle.mkdir()
    session = Session(root)
    state = {'status': 'running', 'run_id': run_id, 'baseline': BASELINE,
             'image_id': os.environ['ARTIFACT_IMAGE_ID'], 'started_utc': datetime.now(timezone.utc).isoformat()}
    write_json(root / 'state.json', state)
    try:
        state['environment'] = session.environment()
        arch = {'aarch64': 'armv8', 'x86_64': 'x86_64'}.get(platform.machine())
        if not arch:
            raise RuntimeError('Only native Linux ARM64 or AMD64 builders are defined')
        lock_input = KIT / 'locks' / f'{arch}.lock'
        if not lock_input.exists() and not bootstrap:
            raise RuntimeError('No reviewed lock for this architecture. First resolution requires create --bootstrap; review and freeze before routine reuse.')
        profiles = bundle / 'profiles'
        profiles.mkdir()
        for build_type in ('Release', 'Debug'):
            (profiles / build_type).write_text(profile(arch, build_type))
        (profiles / 'build').write_text(profile(arch, 'Release'))
        shutil.copytree(KIT / 'consumer', bundle / 'consumer')
        state['input_sha256'] = tree_hashes(KIT)
        state['bootstrap'] = not lock_input.exists()
        if lock_input.exists():
            shutil.copyfile(lock_input, bundle / 'conan.lock')
        lists = []
        state['builds'] = {}
        for build_type in ('Release', 'Debug'):
            output = root / build_type
            graph_file = bundle / f'graph-{build_type}.json'
            args = ['conan', 'install', bundle / 'consumer', '-of', output,
                    '-pr:b', profiles / 'build', '-pr:h', profiles / build_type,
                    '--build=*', '--format=json', '--out-file', graph_file,
                    '--lockfile-out', bundle / 'conan.lock']
            if (bundle / 'conan.lock').exists():
                args += ['--lockfile', bundle / 'conan.lock']
            else:
                args += ['--lockfile=']
            session.run(*args)
            check_graph(json.loads(graph_file.read_text()))
            state['builds'][build_type] = compile_consumer(session, bundle / 'consumer', output, build_type)
            list_file = bundle / f'packages-{build_type}.json'
            session.run('conan', 'list', f'--graph={graph_file}', '--format=json', '--out-file', list_file)
            lists.append(json.loads(list_file.read_text()))
        packages = merge_lists(lists)
        write_json(bundle / 'packages.json', packages)
        state['identities'] = sorted(identity_set(packages))
        # Conan 2.15 check-integrity supports a pattern, not the newer --list.
        # This cache is private to the batch and contains only its dependency graph.
        session.run('conan', 'cache', 'check-integrity', '*#*:*#*')
        session.run('conan', 'cache', 'save', '--list', bundle / 'packages.json', '--file', bundle / 'conan-cache.tgz')
        # Store license files actually shipped with each package, not an invented audit.
        licenses = bundle / 'licenses'
        licenses.mkdir()
        state['licenses'] = {}
        for reference in state['identities']:
            if ':' not in reference:
                continue
            package_path = Path(session.run('conan', 'cache', 'path', reference).strip())
            files = [p for p in package_path.rglob('*') if p.is_file() and
                     ('licenses' in p.parts or p.name.lower().startswith(('license', 'copying', 'notice', 'copyright')))]
            name = reference.replace('/', '_').replace('#', '_').replace(':', '_')
            state['licenses'][reference] = []
            for file in files:
                relative = file.relative_to(package_path)
                destination = licenses / name / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(file, destination)
                state['licenses'][reference].append(str(relative))
        state['status'] = 'built'
        state['bundle_sha256'] = tree_hashes(bundle)
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        state['commands'] = session.commands
        state['transcript_sha256'] = digest(root / 'transcript.txt')
        write_json(bundle / 'manifest.json', state)
        (STORE / 'last-built').write_text(run_id + '\n')
        print(f'Built {len(packages["Local Cache"])} recipes. Offline verification still required: {run_id}', flush=True)
    except Exception as error:
        state['status'] = 'failed'
        state['error'] = str(error)
        raise
    finally:
        write_json(root / 'state.json', state)


def resolve_run(run_id):
    if not run_id:
        run_id = (STORE / 'last-built').read_text().strip()
    if not re.fullmatch(r'\d{8}T\d{6}Z-[a-f0-9]{8}', run_id):
        raise RuntimeError('Invalid run ID; pass the ID printed by create')
    return STORE / 'runs' / run_id


def verify(run_id):
    producer = resolve_run(run_id)
    bundle = producer / 'bundle'
    root = Path(tempfile.mkdtemp(prefix='verify-', dir=STORE))
    session = Session(root)
    state = {'status': 'running', 'run_id': producer.name, 'offline': True,
             'image_id': os.environ['ARTIFACT_IMAGE_ID'], 'checks': [], 'builds': {}}
    write_json(producer / 'verification.json', state)
    (STORE / 'last-verification-attempt').write_text(producer.name + '\n')
    try:
        manifest = json.loads((bundle / 'manifest.json').read_text())
        if manifest['status'] != 'built' or manifest['image_id'] != os.environ['ARTIFACT_IMAGE_ID']:
            raise RuntimeError('Use the exact builder image recorded in this bundle')
        actual_hashes = tree_hashes(bundle)
        actual_hashes.pop('manifest.json')
        if actual_hashes != manifest['bundle_sha256']:
            raise RuntimeError('Bundle input checksum mismatch (including added/missing files)')
        state['verifier_sha256'] = digest(KIT / 'manage.py')
        consumer = root / 'consumer'
        shutil.copytree(bundle / 'consumer', consumer)
        state['environment'] = session.environment()
        session.run('conan', 'remote', 'disable', '*')
        # Negative control: the entirely empty cache must NOT satisfy the consumer.
        negative = session.run('conan', 'install', consumer, '-of', root / 'empty',
                               '-pr:b', bundle / 'profiles/build', '-pr:h', bundle / 'profiles/Release',
                               '--lockfile', bundle / 'conan.lock', '--build=never', '--no-remote', failure=True)
        if 'not found' not in negative.lower() and 'unable to find' not in negative.lower():
            raise RuntimeError('Empty-cache failure was not a missing dependency')
        state['checks'].append('empty-cache-rejected')
        session.run('conan', 'cache', 'restore', bundle / 'conan-cache.tgz')
        session.run('conan', 'cache', 'check-integrity', '*#*:*#*')
        state['checks'].append('restored-cache-integrity')
        lists = []
        for build_type in ('Release', 'Debug'):
            output = root / build_type
            graph_file = root / f'graph-{build_type}.json'
            session.run('conan', 'install', consumer, '-of', output,
                        '-pr:b', bundle / 'profiles/build', '-pr:h', bundle / 'profiles' / build_type,
                        '--lockfile', bundle / 'conan.lock', '--build=never', '--no-remote',
                        '--format=json', '--out-file', graph_file)
            graph = json.loads(graph_file.read_text())
            nodes = check_graph(graph)
            if any(n.get('binary') in ('Build', 'Download') for n in nodes):
                raise RuntimeError('Offline verification unexpectedly built/downloaded a dependency')
            state['builds'][build_type] = compile_consumer(session, consumer, output, build_type)
            list_file = root / f'packages-{build_type}.json'
            session.run('conan', 'list', f'--graph={graph_file}', '--format=json', '--out-file', list_file)
            lists.append(json.loads(list_file.read_text()))
            state['checks'].append(f'{build_type}-offline-install-compile-test-installed-run')
        if identity_set(merge_lists(lists)) != set(manifest['identities']):
            raise RuntimeError('Restored package revisions/IDs differ from the produced closure')
        state['checks'].append('exact-restored-recipe-and-package-identities')
        wrong = session.run('conan', 'install', consumer, '-of', root / 'wrong-abi',
                            '-pr:b', bundle / 'profiles/build', '-pr:h', bundle / 'profiles/Release',
                            '-c:h', 'user.lsqy:baseline=unprepared-sdk', '--lockfile', bundle / 'conan.lock',
                            '--build=never', '--no-remote', failure=True)
        if 'Missing binary' not in wrong:
            raise RuntimeError('Wrong-profile failure was not the expected missing binary')
        state['checks'].append('unprepared-sdk-baseline-rejected')
        state['status'] = 'passed'
        state['finished_utc'] = datetime.now(timezone.utc).isoformat()
        (STORE / 'last-verified').write_text(manifest['run_id'] + '\n')
        print(f'OFFLINE VERIFIED: {manifest["run_id"]}', flush=True)
    except Exception as error:
        state['status'] = 'failed'
        state['error'] = str(error)
        raise
    finally:
        state['commands'] = session.commands
        state['transcript_sha256'] = digest(root / 'transcript.txt')
        write_json(root / 'verification.json', state)
        write_json(producer / 'verification.json', state)


def main():
    if not Path('/.dockerenv').exists() or not KIT.is_dir():
        raise RuntimeError('Run through docker/conan-artifacts/run.sh')
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    create_parser = commands.add_parser('create')
    create_parser.add_argument('--bootstrap', action='store_true')
    verify_parser = commands.add_parser('verify')
    verify_parser.add_argument('run_id', nargs='?')
    commands.add_parser('status')
    args = parser.parse_args()
    if args.command == 'create':
        create(args.bootstrap)
    elif args.command == 'verify':
        verify(args.run_id)
    else:
        for marker in ('last-built', 'last-verified', 'last-verification-attempt'):
            path = STORE / marker
            print(f'{marker}: {path.read_text().strip() if path.exists() else "none"}')
        if (STORE / 'last-built').exists():
            root = resolve_run(None)
            state = json.loads((root / 'state.json').read_text())
            print(json.dumps({key: state.get(key) for key in ('status', 'baseline', 'image_id', 'identities')}, indent=2))
        if (STORE / 'last-verification-attempt').exists():
            attempted = resolve_run((STORE / 'last-verification-attempt').read_text().strip())
            result = json.loads((attempted / 'verification.json').read_text())
            print('Latest verification attempt: ' + result['status'])
            if result.get('error'):
                print(result['error'])


if __name__ == '__main__':
    main()
