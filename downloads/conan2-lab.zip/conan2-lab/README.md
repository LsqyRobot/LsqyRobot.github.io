# Conan 2.15.0 独立教学源码

解压后在此目录运行（需要 Docker）：

```bash
bash docker/conan-lab/run.sh build
bash docker/conan-lab/run.sh test
```

说明见 docker/conan-lab/README.md 与 source/downloads/code/conan2_lab/README.md。
没有预编译库、Conan 缓存、凭据或高通 SDK；首次构建需要联网，实验运行断网。
recorded-summary.json / recorded-transcript.txt 是一次 Linux ARM64 原生实验的记录，不是 ARM 交叉或高通板实测。
legacy-conan1-note.md 是原文历史快照，不是 Conan 2 操作指南。
