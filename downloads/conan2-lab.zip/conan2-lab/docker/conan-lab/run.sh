#!/usr/bin/env bash
set -euo pipefail

LAB_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
LAB_IMAGE="${CONAN_LAB_IMAGE:-lsqy-conan-lab:2.15.0}"
LAB_OUTPUT="$LAB_ROOT/build/conan-lab"
LAB_ACTION="${1:-test}"

case "$LAB_ACTION" in
  build)
    docker build -t "$LAB_IMAGE" -f "$LAB_ROOT/docker/conan-lab/Dockerfile" "$LAB_ROOT/docker/conan-lab"
    ;;
  test|shell|snapshot)
    LAB_UID="$(id -u)"
    LAB_GID="$(id -g)"
    if [[ "$LAB_UID" == 0 ]]; then
      printf 'Run as your ordinary host user, not through sudo.\n' >&2
      exit 2
    fi
    mkdir -p "$LAB_OUTPUT"
    LAB_IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$LAB_IMAGE")"
    LAB_COMMAND=(python3 -B /lab/run_lab.py)
    LAB_TTY=''
    LAB_OUTPUT_ACCESS=''
    if [[ "$LAB_ACTION" == shell ]]; then
      LAB_COMMAND=(bash)
      LAB_TTY='--tty'
    elif [[ "$LAB_ACTION" == snapshot ]]; then
      LAB_COMMAND=(python3 -B /lab/run_lab.py --verify)
      LAB_OUTPUT_ACCESS=',readonly'
    fi
    docker run --rm -i ${LAB_TTY:+$LAB_TTY} \
      --network none --read-only --cap-drop ALL \
      --user "$LAB_UID:$LAB_GID" --security-opt no-new-privileges \
      --memory 1g --cpus 2 --pids-limit 128 \
      --env "CONAN_LAB_IMAGE_ID=$LAB_IMAGE_ID" \
      --env CONAN_HOME=/work/conan-home \
      --tmpfs /tmp:rw,exec,nosuid,nodev,mode=1777,size=128m \
      --tmpfs /work:rw,exec,nosuid,nodev,mode=1777,size=512m \
      --mount "type=bind,source=$LAB_ROOT/source/downloads/code/conan2_lab,target=/lab,readonly" \
      --mount "type=bind,source=$LAB_ROOT/docker/conan-lab,target=/contract,readonly" \
      --mount "type=bind,source=$LAB_OUTPUT,target=/work/out$LAB_OUTPUT_ACCESS" \
      "$LAB_IMAGE" "${LAB_COMMAND[@]}"
    if [[ "$LAB_ACTION" == snapshot ]]; then
      # Only verified text/JSON evidence is published, never Conan cache or ELF.
      cp "$LAB_OUTPUT/summary.json" "$LAB_ROOT/source/downloads/code/conan2_lab/recorded-summary.json"
      cp "$LAB_OUTPUT/transcript.txt" "$LAB_ROOT/source/downloads/code/conan2_lab/recorded-transcript.txt"
    fi
    ;;
  *)
    printf 'Usage: bash docker/conan-lab/run.sh {build|test|shell|snapshot}\n' >&2
    exit 2
    ;;
esac
