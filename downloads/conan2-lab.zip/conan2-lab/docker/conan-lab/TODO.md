# Conan 实验验证边界

## 当前实现

- 独立 Conan 2.15.0 镜像与本地 C++ 库、consumer、`test_package`。
- 每次全新 Conan cache、无远端、本地版本/RREV/二进制配置/锁文件语义断言。
- 正常消费与预期缺失二进制都保留真实命令、退出码与输出。
- 最近运行状态、输入/镜像/日志哈希校验后，才允许发布摘要快照。
- 独立复核正文的 `conan build` 输出路径与手动 lockfile 命令；Linux 共享库 `test_package` 和 upload 帮助参数也纳入检查，不执行远程上传。

是否完成实测，以 `build/conan-lab/last-run.json` 与验证过的下载摘要为准；此列表本身不充当通过记录。

## 未覆盖的工作

### P1：ARM 交叉部署

当前是 Linux 容器的原生编译，不是从 x86_64 交叉到 ARM 的验证。需要明确目标板、目标 libc/C++ ABI、真实 sysroot 与交叉工具链；入口为 `mymath/conanfile.py`、`consumer/conanfile.py` 和单独维护的 host/build profiles。验收需要记录两份 profile、输出 ELF 架构、动态加载器、依赖库，并在目标板执行结果；修改 `arch` 字段不算完成。

### P1：远端制品库发布与权限

尚未建立或访问 remote。需要用户选定并授权 Conan 2 兼容远端、仓库策略与凭据获取方式。使用临时专用测试仓库验证上传、干净 cache 下载和权限拒绝，并保留完整 RREV/package ID/PREV；不得把 token 写入源码、镜像层或公开日志。

### P2：其他平台／共享库

主实验默认构建静态库；独立手动复核已运行当前 ARM64 Linux 的共享库 `test_package`。仍需另测原生 AMD64、Windows 导出符号及脱离缓存的共享库运行时部署；已有 `shared`/`fPIC` 选项不代表这些组合已全部验证。验收包含对应 `test_package`、consumer 和库搜索路径检查。

### P2：完整环境冻结

当前固定 Conan 和 base digest，并记录其余版本。若要更强的长期环境复现，需要保存 APT snapshot、带哈希的 Python 依赖锁、profiles/config 与镜像 digest；不能将普通 Conan dependency lockfile 宣称为二进制、工具链或运行系统的完整锁定。
