#!/usr/bin/env python3
"""Verify the article's manual commands inside the disposable lab container.

Does not replace run_lab.py or its 24-check evidence. Upload is help-only.
"""

from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import subprocess
import tempfile


def input_hashes():
    inputs = [Path(__file__), Path("/contract/Dockerfile")]
    for name in ("mymath", "consumer"):
        inputs.extend(p for p in (Path("/lab") / name).rglob("*") if p.is_file())
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(inputs)}


def main():
    if not Path("/.dockerenv").exists() or not Path("/lab/mymath").is_dir():
        raise RuntimeError("Run only inside bash docker/conan-lab/run.sh shell")
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify", action="store_true", help="Verify existing manual evidence, without building")
    args = parser.parse_args()
    output = Path("/work/out")
    if args.verify:
        result = json.loads((output / "manual-summary.json").read_text())
        if (result.get("status") != "passed" or not result.get("checks")
                or not all(check["passed"] for check in result["checks"])
                or result["source_sha256"] != input_hashes()
                or result["image_id"] != os.environ.get("CONAN_LAB_IMAGE_ID")
                or result["transcript_sha256"] != hashlib.sha256(
                    (output / "manual-transcript.txt").read_bytes()).hexdigest()):
            raise RuntimeError("Manual evidence does not match a passed run with current inputs/image/log")
        print("Manual evidence verified: passed run, current inputs, image and transcript")
        return
    workspace = Path(tempfile.mkdtemp(prefix="manual-demo-", dir="/work"))
    env = os.environ.copy()
    env["CONAN_HOME"] = tempfile.mkdtemp(prefix="manual-conan-home-", dir="/work")
    for name in ("mymath", "consumer"):
        shutil.copytree(Path("/lab") / name, workspace / name)
    summary = {
        "status": "running",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "architecture": platform.machine(),
        "image_id": env.get("CONAN_LAB_IMAGE_ID"),
        "commands": [],
        "checks": [],
        "boundaries": ["Native Linux only; no cross compilation or target board",
                       "Upload help only; no remote login, upload or download"],
    }
    summary["source_sha256"] = input_hashes()
    (output / "manual-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    transcript = output / "manual-transcript.txt"
    with transcript.open("w", buffering=1) as log:
        def run(command, expected_failure=False):
            argv = shlex.split(command)
            print("$ " + command, flush=True)
            log.write("\n$ " + command + "\n")
            result = subprocess.run(argv, cwd=workspace, env=env,
                                    capture_output=True, text=True, timeout=180)
            log.write("--- stdout ---\n" + result.stdout)
            log.write("--- stderr ---\n" + result.stderr)
            log.write(f"\n[exit_code={result.returncode}]\n")
            summary["commands"].append({"argv": argv, "exit_code": result.returncode,
                                        "expected_failure": expected_failure})
            if (result.returncode == 0) == expected_failure:
                raise RuntimeError(command + "\n" + result.stdout + result.stderr)
            return result.stdout + result.stderr

        def check(name, condition, evidence):
            if not condition:
                raise AssertionError(f"{name}: {evidence}")
            summary["checks"].append({"name": name, "passed": True, "evidence": evidence})
            print("PASS: " + name, flush=True)

        try:
            version = run("conan --version").strip()
            check("conan-2.15.0", version == "Conan version 2.15.0", version)
            run("conan profile detect")
            summary["detected_profile"] = (Path(env["CONAN_HOME"]) / "profiles/default").read_text()
            run('conan remote disable "*"')
            remotes = run("conan remote list --format=json")
            check("all-remotes-disabled", all(not r["enabled"] for r in json.loads(remotes)), remotes.strip())

            for build_type in ("Release", "Debug"):
                result = run("conan create mymath --version=1.0 -pr:b default -pr:h default "
                             f"-s:h build_type={build_type} --no-remote")
                marker = f"test_package: sum=5; version=1.0; build_type={build_type}"
                check(f"manual-create-{build_type}", marker in result, marker)
            run('conan list "mymath/1.0#*:*#*" --format=json')

            shared = run("conan create mymath --version=1.0 -pr:b default -pr:h default "
                         '-s:h build_type=Release -o:h "mymath/*:shared=True" --no-remote')
            check("optional-linux-shared-test-package",
                  "test_package: sum=5; version=1.0; build_type=Release" in shared,
                  "Shared package test_package linked and executed on native Linux")

            run("conan install consumer -of out/consumer-release -pr:b default -pr:h default "
                "-s:h build_type=Release --build=never --no-remote")
            run("conan build consumer -of out/consumer-release -pr:b default -pr:h default "
                "-s:h build_type=Release")
            executable = "./out/consumer-release/build/Release/robot-consumer"
            check("manual-conan-build-output-path", (workspace / executable).is_file(), executable)
            result = run(executable).strip()
            check("manual-conan-build-runs-release",
                  result == "consumer: sum=5; version=1.0; build_type=Release", result)

            run("conan lock create consumer -pr:b default -pr:h default -s:h build_type=Release "
                "--no-remote --lockfile-out=consumer/conan.lock")
            lock = json.loads((workspace / "consumer/conan.lock").read_text())
            summary["lockfile"] = lock
            check("manual-lock-contains-1.0-rrev",
                  len(lock["requires"]) == 1 and lock["requires"][0].startswith("mymath/1.0#"),
                  lock["requires"])
            run("conan create mymath --version=1.1 -pr:b default -pr:h default "
                "-s:h build_type=Release --no-remote")
            unlocked = run("conan graph info consumer -pr:b default -pr:h default "
                           '-s:h build_type=Release --no-remote --lockfile=""')
            locked = run("conan graph info consumer -pr:b default -pr:h default "
                         "-s:h build_type=Release --no-remote --lockfile=consumer/conan.lock")
            check("manual-unlocked-selects-1.1", "mymath/1.1#" in unlocked, "Graph includes mymath/1.1")
            check("manual-locked-selects-1.0", "mymath/1.0#" in locked and "mymath/1.1#" not in locked,
                  "Graph includes mymath/1.0; does not include mymath/1.1")
            run("conan install consumer -of out/consumer-debug -pr:b default -pr:h default "
                "-s:h build_type=Debug --lockfile=consumer/conan.lock --build=never --no-remote")
            missing = run("conan install consumer -of out/missing-binary -pr:b default -pr:h default "
                          "-s:h build_type=RelWithDebInfo --lockfile=consumer/conan.lock "
                          "--build=never --no-remote", expected_failure=True)
            check("manual-missing-binary-is-expected-failure", "Missing binary" in missing,
                  "RelWithDebInfo install failed with Missing binary and --build=never")

            help_text = run("conan upload --help")
            for flag in ("--list", "--check", "--dry-run", "--confirm"):
                check("upload-help-" + flag.removeprefix("--"), flag in help_text,
                      f"Conan 2.15.0 upload --help contains {flag}; upload not executed")
            summary["status"] = "passed"
        except Exception as error:
            summary["status"] = "failed"
            summary["error"] = str(error)
            raise
        finally:
            summary["finished_utc"] = datetime.now(timezone.utc).isoformat()
            log.flush()
            summary["transcript_sha256"] = hashlib.sha256(transcript.read_bytes()).hexdigest()
            (output / "manual-summary.json").write_text(
                json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    print(f"Manual checks passed: {len(summary['checks'])}", flush=True)


if __name__ == "__main__":
    main()
