# Conan 2 本地制品实验

从站点仓库根目录运行：

```bash
bash docker/conan-lab/run.sh build
bash docker/conan-lab/run.sh test
bash docker/conan-lab/run.sh snapshot
```

宿主只需要 Bash 和运行中的 Docker；编译器、CMake、Python 和 Conan 全部来自本实验的独立镜像。没有 Compose 服务，也不会修改其他实验镜像或运行服务。

镜像固定 Conan **2.15.0** 与 Ubuntu 22.04 的多架构 base digest。2.15.0 是本文的教学复跑版本，不是最新版本。APT 安全更新和 Conan 的 Python 间接依赖没有全部锁定；实际版本、架构、编译器 target、镜像 ID、源码 SHA-256 随每次成功实验保存，不能据此声称镜像重建逐字节一致。

`test` 在一个临时非 root 容器中执行；容器无网络，源码和根文件系统只读。只写有界 tmpfs 与 `build/conan-lab` 证据目录。每次运行生成全新的 `CONAN_HOME`，移除其中的默认 remotes；所有解析命令还明确使用 `--no-remote`。不接入或修改用户已有的 Conan cache，不使用第三方 Conan 包，不登录或上传制品库。

`source/downloads/code/conan2_lab/run_lab.py` 是实验与断言入口：

1. 检查实际 Conan 版本，检测当前容器编译器 profile 并保存内容。
2. 创建 `mymath/1.0` 的 Release、Debug 包，并执行真正链接安装后软件包的 `test_package`。
3. 比较 recipe revision、package ID、package revision；验证 build type 会改变 package ID。
4. 为 consumer 的 `mymath/[>=1.0 <2.0]` 依赖创建锁文件。
5. 创建 `mymath/1.1`，验证无锁 consumer 选择并运行 1.1。
6. 修改临时副本的一个源码注释，再创建 1.0；验证相同版本产生新的 RREV，而相同配置的 package ID 不变。
7. 用原锁文件分别构建并运行 Release、Debug consumer，验证仍使用原始 1.0 RREV，但各自选择匹配配置的包。
8. 请求从未创建的 RelWithDebInfo 配置并指定 `--build=never`，验证得到 `Missing binary`。这是预期失败，不是实验失败。

两种 CMake 集成都在源码中：recipe 用 `CMakeToolchain`、`CMakeDeps` 和 `cmake_layout`；consumer 的 `find_package(mymath CONFIG REQUIRED)` 只链接 `mymath::mymath`。消费端不会直接引用库的原始源码目录。

## 证据与快照

`build/conan-lab` 保存最新状态 `last-run.json`、成功摘要 `summary.json`、完整 stdout/stderr `transcript.txt`、每次 Conan JSON 图、检测 profile 和本次锁文件。

`snapshot` 先在 Docker 内检查最近运行状态、源码哈希、当前镜像 ID 和 transcript 哈希。只有检查通过才将真实 `recorded-summary.json`、`recorded-transcript.txt` 复制到网站下载目录；不会发布 cache、ELF 或动态库。修改实验输入后需要重跑 `test`，不能用旧结果冒充验证。

`recorded-summary.json` 只表示该次实际运行；新的输入、镜像或不同机器必须重新实测。锁文件中的时间戳与临时缓存路径也会变化，本实验验证语义而非要求日志字节恒定。

## 交互入口

```bash
bash docker/conan-lab/run.sh shell
# 容器内重新完整运行：
python3 -B /lab/run_lab.py
```

交互 shell 的默认 `CONAN_HOME=/work/conan-home` 与自动 runner 每次创建的独立缓存不同；不要误用空的交互缓存去判断自动实验是否创建成功。自动实验的所有实际命令和路径在 transcript 中。

## 正文手动命令的独立复核

在上述交互容器内运行：

```bash
python3 -B /contract/check_manual.py
python3 -B /contract/check_manual.py --verify
```

这组检查新建另一份临时 cache 和工作区，不覆盖主实验的 24 项检查与日志。它复跑正文的 `conan create`、`conan install`、`conan build`、lockfile 对照与预期缺失二进制命令，并检查 `out/consumer-release/build/Release/robot-consumer` 确实生成且可运行。额外验证 Linux `shared=True` 的 `test_package`；远程部分只执行 `conan upload --help`，核对参数存在，不执行 upload、登录或下载。

独立结果保存在 `build/conan-lab/manual-summary.json`、`manual-transcript.txt`。`--verify` 核对该结果的成功状态、源码、镜像和日志哈希；下载目录中的 `recorded-manual-summary.json`、`recorded-manual-transcript.txt` 是通过这些检查后的真实快照。2026-09-09 的 ARM64 Linux 原生实测共通过 15 项独立检查，不等同于上板或远程发布验收。

更多源码说明见 [下载目录 README](../../source/downloads/code/conan2_lab/README.md)。未测边界与后续验收见 [TODO.md](TODO.md)。本站页面与下载链接检查由主站工作流负责，不由这个 Docker runner 启动 Hexo。
